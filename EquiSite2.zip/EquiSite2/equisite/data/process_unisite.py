"""
process_unisite_setpred.py  —  UniSite-DS -> GDEGAN_V2 (set-prediction / self-nominated-center) converter.

NON-DESTRUCTIVE: this is a brand-new file. It does NOT import or modify any existing
GDEGAN_V2 code (binding_dataset2.py, utils/protein_features2.py are left untouched).

What one output record is
-------------------------
ONE record = ONE UniProt protein (structure-space, "Option B"):
  * graph nodes  = the residues of the representative top-level {unp}.pdb that are mapped to UniProt
  * node features= ESM-2 (over the FULL canonical sequence, indexed at each node's UniProt position)
                   + 20-dim one-hot amino-acid
  * SET labels   = per-pocket residue masks projected onto the graph nodes via map_dict
  * center-method targets (self-nominated-center design):
        y_foreground [N]  : residue is in ANY pocket
        q_centerness [N]  : residue is the self-nominated CENTER of some pocket
        vote_target  [N,3]: offset from residue to its pocket centroid (0 for background)
        owner        [N]  : which pocket a residue belongs to (-1 = background)

Everything is computed in the MAIN-pdb coordinate frame. The siteN/ ligand & protein files
are NEVER read (they live in different frames; they were only UniSite's offline curation inputs).

Output: a single pickle = list[dict] (mirrors the coach_420_processed.pkl style), plus a
text report with coverage statistics (the "are binding residues observed?" gate).

Usage
-----
  conda run -n ainimesh python process_unisite_setpred.py \
      --dataset_dir unisite/Datasets/unisite-ds-v1 \
      --output_dir  unisite/preprocessed_data \
      [--limit 20] [--no_esm] [--device cuda:0]
"""

import os
import csv
import glob
import pickle
import argparse
from datetime import datetime

import numpy as np

# ----------------------------------------------------------------------------------
# amino-acid tables (same 20-class ordering as utils/protein_features2.py THREE_TO_ONE)
# ----------------------------------------------------------------------------------
THREE_TO_ONE = {
    "ALA": "A", "CYS": "C", "ASP": "D", "GLU": "E", "PHE": "F",
    "GLY": "G", "HIS": "H", "ILE": "I", "LYS": "K", "LEU": "L",
    "MET": "M", "ASN": "N", "PRO": "P", "GLN": "Q", "ARG": "R",
    "SER": "S", "THR": "T", "VAL": "V", "TRP": "W", "TYR": "Y",
}
ONE_LETTERS = [THREE_TO_ONE[k] for k in THREE_TO_ONE]     # A,C,D,...,Y  (index 0..19)
ONE_TO_IDX = {c: i for i, c in enumerate(ONE_LETTERS)}


# ----------------------------------------------------------------------------------
# robust CA parser for the representative {unp}.pdb
#   - keeps ATOM ... CA only (ANISOU / HETATM / TER auto-skipped)
#   - dedupes alternate locations (keeps first occurrence per residue)
#   - returns residues in file order
# ----------------------------------------------------------------------------------
def parse_ca_atoms(pdb_path):
    residues = []          # list of dict(resnum, icode, chain, resname, xyz)
    seen = set()
    with open(pdb_path) as f:
        for line in f:
            if not line.startswith("ATOM"):
                continue
            if line[12:16].strip() != "CA":
                continue
            chain = line[21]
            resnum = line[22:26].strip()
            icode = line[26].strip()
            key = (chain, resnum, icode)
            if key in seen:                      # alternate location -> keep first
                continue
            seen.add(key)
            residues.append({
                "resnum": resnum,
                "icode": icode,
                "chain": chain,
                "resname": line[17:20].strip(),
                "xyz": [float(line[30:38]), float(line[38:46]), float(line[46:54])],
            })
    return residues


# ----------------------------------------------------------------------------------
# ESM-2 wrapper (over the FULL canonical sequence)
# ----------------------------------------------------------------------------------
class ESMEncoder:
    def __init__(self, model_name="esm2_t33_650M_UR50D", device="cuda:0"):
        import torch
        import esm
        self.torch = torch
        self.device = device
        self.model, self.alphabet = getattr(esm.pretrained, model_name)()
        self.batch_converter = self.alphabet.get_batch_converter()
        self.repr_layer = 33 if "t33" in model_name else 6
        self.dim = 1280 if "t33" in model_name else 320
        self.model.to(device).eval()

    def embed(self, seq):
        """seq (str, full canonical) -> np.float32 [len(seq), dim]."""
        _, _, toks = self.batch_converter([("p", seq)])
        toks = toks.to(self.device)
        with self.torch.no_grad():
            out = self.model(toks, repr_layers=[self.repr_layer])
        rep = out["representations"][self.repr_layer][0, 1:len(seq) + 1]   # strip BOS/EOS
        assert rep.shape[0] == len(seq), (rep.shape, len(seq))
        return rep.cpu().numpy().astype(np.float32)


# ----------------------------------------------------------------------------------
# convert ONE protein
# ----------------------------------------------------------------------------------
def convert_protein(unp, dataset_dir, meta_row, esm_encoder=None):
    """Returns (record_dict, stats_dict) or raises on a hard failure."""
    pkl_path = os.path.join(dataset_dir, "_pkl_files", f"{unp}.pkl")
    pdb_path = os.path.join(dataset_dir, unp, f"{unp}.pdb")
    with open(pkl_path, "rb") as f:
        d = pickle.load(f)

    sequence = d["sequence"]                       # full canonical UniProt sequence
    seq_len = len(sequence)
    map_dict = d["map_dict"]                        # {main-pdb-resnum(str) -> uniprot-pos(str, 1-based)}
    target = d["target"]
    pocket_masks_seq = np.asarray(target["pocket_masks"], dtype=np.float32)   # [K, seq_len]
    K = pocket_masks_seq.shape[0]

    # ---- build graph nodes from the representative pdb (mapped residues only) ----
    residues = parse_ca_atoms(pdb_path)
    nodes = []            # kept residues
    uni_pos = []          # 0-based uniprot position per node
    dup_resnum = 0
    seen_resnum = set()
    for r in residues:
        rn = r["resnum"]
        if rn not in map_dict:                      # unmapped observed residue -> drop (UniSite does the same)
            continue
        if rn in seen_resnum:                       # same resnum on >1 chain in the representative -> keep first
            dup_resnum += 1
            continue
        seen_resnum.add(rn)
        u = int(map_dict[rn]) - 1                   # 0-based uniprot index
        if u < 0 or u >= seq_len:
            continue
        nodes.append(r)
        uni_pos.append(u)

    N = len(nodes)
    if N == 0:
        raise ValueError(f"{unp}: 0 mapped nodes")
    uni_pos = np.asarray(uni_pos, dtype=np.int64)
    coords = np.asarray([n["xyz"] for n in nodes], dtype=np.float32)          # [N,3]

    # ---- amino-acid identity checks (canonical seq vs structure) ----
    seq_aa = [sequence[u] for u in uni_pos]                                   # from canonical seq
    struct_aa = [THREE_TO_ONE.get(n["resname"], "X") for n in nodes]         # from pdb
    aa_mismatch = int(sum(1 for a, b in zip(seq_aa, struct_aa) if a != b))

    # one-hot (from canonical-seq identity, to stay aligned with ESM) + z index (1..20, 0=unknown)
    onehot = np.zeros((N, 20), dtype=np.float32)
    z = np.zeros((N,), dtype=np.int64)
    for i, c in enumerate(seq_aa):
        if c in ONE_TO_IDX:
            onehot[i, ONE_TO_IDX[c]] = 1.0
            z[i] = ONE_TO_IDX[c] + 1

    # ---- project per-pocket masks seq-space [K,seq_len] -> node-space [K,N] ----
    site_masks = pocket_masks_seq[:, uni_pos].astype(np.float32)             # [K, N]
    # coverage: binding residues in seq-space vs how many landed on a node
    seq_binding = pocket_masks_seq.sum(axis=1)                               # [K]
    node_binding = site_masks.sum(axis=1)                                    # [K]
    keep = node_binding > 0
    dropped_pockets = int((~keep).sum())
    site_masks = site_masks[keep]
    site_labels = np.zeros((site_masks.shape[0],), dtype=np.int64)           # all class 0
    Kk = site_masks.shape[0]
    if Kk == 0:                                                              # all pockets unobserved -> skip protein
        return None, {"name": unp, "empty": True}

    # ---- geometry targets (self-nominated-center design), all in MAIN frame ----
    y_foreground = (site_masks.sum(axis=0) > 0).astype(np.int64)            # [N]
    centroids = np.zeros((Kk, 3), dtype=np.float32)
    members_list = []
    for k in range(Kk):
        members = np.where(site_masks[k] > 0)[0]
        members_list.append(members)
        centroids[k] = coords[members].mean(axis=0)
    # DISTINCT center residue per pocket: assign greedily, largest pocket first,
    # each pocket takes its nearest member NOT already claimed by another pocket.
    center_res_idx = np.full((Kk,), -1, dtype=np.int64)
    claimed = set()
    for k in sorted(range(Kk), key=lambda j: -len(members_list[j])):
        members = members_list[k]
        order = members[np.argsort(((coords[members] - centroids[k]) ** 2).sum(1))]
        pick = next((int(m) for m in order if int(m) not in claimed), int(order[0]))
        center_res_idx[k] = pick
        claimed.add(pick)

    q_centerness = np.zeros((N,), dtype=np.int64)
    q_centerness[center_res_idx] = 1

    owner = np.full((N,), -1, dtype=np.int64)
    vote_target = np.zeros((N, 3), dtype=np.float32)
    for i in np.where(y_foreground > 0)[0]:
        cand = np.where(site_masks[:, i] > 0)[0]                             # pockets this residue is in
        dists = ((centroids[cand] - coords[i]) ** 2).sum(1)
        k = int(cand[np.argmin(dists)])
        owner[i] = k
        vote_target[i] = centroids[k] - coords[i]

    # ---- ESM (over full canonical sequence), indexed at node uniprot positions ----
    if esm_encoder is not None:
        esm_full = esm_encoder.embed(sequence)                              # [seq_len, dim]
        esm_nodes = esm_full[uni_pos]                                       # [N, dim]
        esm_dim = esm_nodes.shape[1]
    else:
        esm_nodes = None
        esm_dim = 0

    record = {
        "name": unp,
        # --- structure / features (coach-style keys) ---
        "coordinates": coords,                       # [N,3]
        "res_features_onehot": onehot,               # [N,20]
        "res_features_esm": esm_nodes,               # [N,1280] or None
        "res_names": struct_aa,                      # 1-letter, from structure
        "res_numbers": [int(n["resnum"]) for n in nodes],
        "chains": [n["chain"] for n in nodes],
        "sequence": sequence,                        # full canonical uniprot sequence
        "z": z,                                      # [N] aa index 1..20 (0=unknown)
        # --- back-compat single-mask label ---
        "res_binding": y_foreground,                 # [N]  (= foreground; keeps old loaders working)
        "pocket_center": centroids.mean(axis=0) if Kk else coords.mean(axis=0),
        # --- SET / center-method targets ---
        "site_masks": site_masks,                    # [K,N]
        "site_labels": site_labels,                  # [K]
        "site_centroids": centroids,                 # [K,3]
        "center_res_idx": center_res_idx,            # [K]
        "q_centerness": q_centerness,                # [N]
        "vote_target": vote_target,                  # [N,3]
        "owner": owner,                              # [N]  (-1 background)
        # --- bookkeeping for eval / seq-space projection ---
        "uniprot_positions": uni_pos,                # [N] 0-based positions into `sequence`
        "seq_len": seq_len,
        "num_residues": N,
        "num_sites": int(Kk),
        "esm_dim": esm_dim,
    }

    stats = {
        "name": unp, "N": N, "seq_len": seq_len,
        "K_meta": int(meta_row["number_sites"]), "K_used": int(Kk),
        "dropped_pockets": dropped_pockets, "dup_resnum": dup_resnum,
        "aa_mismatch": aa_mismatch,
        "binding_seq": int(seq_binding.sum()), "binding_node": int(node_binding.sum()),
    }
    return record, stats


# ----------------------------------------------------------------------------------
# main
# ----------------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset_dir", default="unisite/Datasets/unisite-ds-v1")
    ap.add_argument("--output_dir", default="unisite/preprocessed_data")
    ap.add_argument("--esm_model", default="esm2_t33_650M_UR50D")
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--limit", type=int, default=0, help="process only first N proteins (0=all)")
    ap.add_argument("--no_esm", action="store_true", help="skip ESM (fast geometry/label validation)")
    ap.add_argument("--out_name", default="unisite_setpred_processed.pkl")
    args = ap.parse_args()

    ds = os.path.abspath(args.dataset_dir)
    out_dir = os.path.join(os.path.abspath(args.output_dir), "unisite-ds-v1")
    os.makedirs(out_dir, exist_ok=True)

    # metadata
    meta = {}
    with open(os.path.join(ds, "metadata.csv")) as f:
        for row in csv.DictReader(f):
            meta[row["unp_id"]] = row
    unps = sorted(meta.keys())
    if args.limit:
        unps = unps[:args.limit]
    print(f"[unisite-setpred] {len(unps)} proteins | esm={'OFF' if args.no_esm else args.esm_model} | out={out_dir}")

    esm_encoder = None
    if not args.no_esm:
        print(f"[unisite-setpred] loading ESM {args.esm_model} on {args.device} ...")
        esm_encoder = ESMEncoder(args.esm_model, args.device)

    records, all_stats, failed, skipped_empty = [], [], [], []
    t0 = datetime.now()
    for i, unp in enumerate(unps):
        try:
            rec, st = convert_protein(unp, ds, meta[unp], esm_encoder)
            if rec is None:                         # K==0 after projection -> skip
                skipped_empty.append(unp)
                continue
            records.append(rec)
            all_stats.append(st)
        except Exception as e:
            failed.append((unp, repr(e)))
        if (i + 1) % 250 == 0 or (i + 1) == len(unps):
            el = (datetime.now() - t0).total_seconds()
            print(f"  {i+1}/{len(unps)}  ok={len(records)} failed={len(failed)}  "
                  f"[{el:.0f}s, {(i+1)/max(el,1e-6):.1f} prot/s]")

    tag = "noesm" if args.no_esm else "esm"
    out_path = os.path.join(out_dir, args.out_name if not args.no_esm
                            else args.out_name.replace(".pkl", "_noesm.pkl"))
    with open(out_path, "wb") as f:
        pickle.dump(records, f)

    # ---- report + coverage gate ----
    bs = sum(s["binding_seq"] for s in all_stats)
    bn = sum(s["binding_node"] for s in all_stats)
    dp = sum(s["dropped_pockets"] for s in all_stats)
    mm = sum(s["aa_mismatch"] for s in all_stats)
    tot_res = sum(s["N"] for s in all_stats)
    multi = sum(1 for s in all_stats if s["K_used"] > 1)
    rep = os.path.join(out_dir, f"unisite_setpred_report_{tag}.txt")
    with open(rep, "w") as f:
        f.write(f"UniSite-DS -> set-prediction conversion report ({datetime.now():%Y-%m-%d %H:%M})\n")
        f.write(f"proteins ok={len(records)} failed={len(failed)} skipped_empty(K=0)={len(skipped_empty)}\n")
        f.write(f"skipped_empty names: {skipped_empty}\n")
        f.write(f"multi-site proteins (K>1) = {multi}\n")
        f.write(f"total nodes = {tot_res}\n")
        f.write("\n=== COVERAGE GATE (binding residues observed in the representative structure) ===\n")
        f.write(f"binding residues in seq-space   = {bs}\n")
        f.write(f"binding residues on graph nodes = {bn}\n")
        f.write(f"coverage = {100.0*bn/max(bs,1):.2f}%   (100% => pure-structure model loses no binding residues)\n")
        f.write(f"pockets dropped (0 residues survive projection) = {dp}\n")
        f.write(f"residues where canonical-seq AA != structure AA = {mm} ({100.0*mm/max(tot_res,1):.3f}%)\n")
        if failed:
            f.write("\n=== FAILED ===\n")
            for u, e in failed[:40]:
                f.write(f"  {u}: {e}\n")
            if len(failed) > 40:
                f.write(f"  ... +{len(failed)-40} more\n")
    print(f"[unisite-setpred] saved {len(records)} records -> {out_path}")
    print(f"[unisite-setpred] COVERAGE = {100.0*bn/max(bs,1):.2f}%  | dropped pockets={dp} | report -> {rep}")


if __name__ == "__main__":
    main()
