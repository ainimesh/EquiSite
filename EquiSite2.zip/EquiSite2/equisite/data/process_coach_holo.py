"""
process_coach_holo.py — COACH420 / HOLO4K (raw protein+ligand) -> our set-prediction format,
for DCC/DCA + IoU-AP evaluation against UniSite Table 2.  NEW FILE (non-destructive).

These benchmark sets are PDB-centric and SAME-FRAME (protein.pdb + ligand_N.pdb in one frame),
so ligand-based DCA is valid here (unlike UniSite-DS). One record = one structure:
  nodes = observed CA residues (1:1 with the sequence, no UniProt mapping needed)
  GT site masks = residues with any heavy atom within `cutoff` (4.5A) of a ligand's heavy atoms
  GT ligands    = per-ligand heavy-atom coords (for DCA) and centroids (for DCC)

Usage:
  conda run -n ainimesh python process_coach_holo.py --raw_dir unisite/Extra_datasets/coach420/raw \
      --out unisite/Extra_datasets/coach420_setpred.pkl [--single_chain_only]
"""
import os, glob, pickle, argparse
import numpy as np
from equisite.data.process_unisite import THREE_TO_ONE, ONE_TO_IDX, ESMEncoder


def parse_protein(pdb):
    res = {}; order = []
    with open(pdb) as f:
        for line in f:
            if not line.startswith("ATOM"):
                continue
            if line[16] not in (" ", "A"):                    # altloc
                continue
            elem = (line[76:78].strip() or line[12:16].strip()[:1])
            if elem == "H":                                   # heavy atoms only
                continue
            key = (line[21], line[22:26].strip(), line[26].strip())
            xyz = [float(line[30:38]), float(line[38:46]), float(line[46:54])]
            if key not in res:
                res[key] = {"ca": None, "atoms": [], "resname": line[17:20].strip(), "chain": line[21]}
                order.append(key)
            res[key]["atoms"].append(xyz)
            if line[12:16].strip() == "CA":
                res[key]["ca"] = xyz
    return [res[k] for k in order if res[k]["ca"] is not None]


def parse_ligand(pdb):
    a = []
    with open(pdb) as f:
        for line in f:
            if line.startswith(("HETATM", "ATOM")):
                elem = (line[76:78].strip() or line[12:16].strip()[:1])
                if elem == "H":
                    continue
                a.append([float(line[30:38]), float(line[38:46]), float(line[46:54])])
    return np.asarray(a, np.float32)


def convert(pdir, name, esm, cutoff=4.5):
    nodes = parse_protein(f"{pdir}/protein.pdb")
    N = len(nodes)
    if N == 0 or N > 1022:
        return None, ("skip_len" if N > 1022 else "no_ca")
    ca = np.asarray([n["ca"] for n in nodes], np.float32)
    seq = "".join(THREE_TO_ONE.get(n["resname"], "X") for n in nodes)
    ligs = [l for l in (parse_ligand(f) for f in sorted(glob.glob(f"{pdir}/ligand_*.pdb"))) if len(l) > 0]
    if not ligs:
        return None, "no_ligand"

    site_masks = np.zeros((len(ligs), N), np.float32)
    gt_centers = np.zeros((len(ligs), 3), np.float32)
    node_atoms = [np.asarray(n["atoms"], np.float32) for n in nodes]
    for k, lig in enumerate(ligs):
        gt_centers[k] = lig.mean(0)
        for i, at in enumerate(node_atoms):
            if np.linalg.norm(at[:, None, :] - lig[None, :, :], axis=-1).min() < cutoff:
                site_masks[k, i] = 1
    keep = site_masks.sum(1) > 0                              # drop ligands with no binding residue
    if keep.sum() == 0:
        return None, "no_binding"
    site_masks, gt_centers = site_masks[keep], gt_centers[keep]
    ligs = [l for l, kp in zip(ligs, keep) if kp]

    onehot = np.zeros((N, 20), np.float32); z = np.zeros(N, np.int64)
    for i, c in enumerate(seq):
        if c in ONE_TO_IDX:
            onehot[i, ONE_TO_IDX[c]] = 1.0; z[i] = ONE_TO_IDX[c] + 1
    rec = {
        "name": name, "coordinates": ca, "res_features_onehot": onehot, "z": z, "sequence": seq,
        "res_features_esm": esm.embed(seq) if esm else None,
        "gt_site_masks": site_masks, "gt_centers": gt_centers,
        "ligand_atoms": [l for l in ligs], "num_residues": N, "num_sites": int(len(ligs)),
    }
    return rec, "ok"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--raw_dir", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--single_chain_only", action="store_true")
    ap.add_argument("--device", default="cuda:0")
    ap.add_argument("--no_esm", action="store_true")
    ap.add_argument("--cutoff", type=float, default=4.5)
    args = ap.parse_args()

    dirs = sorted(os.listdir(args.raw_dir))
    if args.single_chain_only:
        dirs = [d for d in dirs if len(d) == 5]               # pdbid(4)+one chain
    esm = None if args.no_esm else ESMEncoder(device=args.device)
    recs = []; reasons = {}
    for i, d in enumerate(dirs):
        rec, why = convert(os.path.join(args.raw_dir, d), d, esm, args.cutoff)
        reasons[why] = reasons.get(why, 0) + 1
        if rec is not None:
            recs.append(rec)
        if (i + 1) % 500 == 0 or i + 1 == len(dirs):
            print(f"  {i+1}/{len(dirs)} ok={len(recs)} {reasons}")
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with open(args.out, "wb") as f:
        pickle.dump(recs, f)
    ns = [r["num_sites"] for r in recs]
    print(f"[done] {len(recs)} structures -> {args.out} | reasons={reasons}")
    print(f"  sites/protein: mean={np.mean(ns):.2f} multi(>1)={sum(1 for n in ns if n>1)}  total sites={sum(ns)}")


if __name__ == "__main__":
    main()
