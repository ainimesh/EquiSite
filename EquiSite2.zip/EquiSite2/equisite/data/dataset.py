"""
unisite_setpred_dataset.py  —  PyG dataset + datamodule for UniSite set-prediction.

NEW FILE (non-destructive): reads the single pkl produced by process_unisite_setpred.py
and honours UniSite's official sequence-identity splits (_train/_test_{0.5,0.7,0.9}.csv or
_benchmark). Keeps the variable-K per-protein GT (`site_masks`, `site_centroids`) as a
per-graph python object via a custom collate (mirrors UniSite's length_collate), so the
per-node training tensors batch natively while the set targets stay a List[dict].

Training uses ONLY per-node tensors (pos, esm, z, y=foreground, q_centerness, vote_target)
— they batch trivially. The set masks are consumed only at eval (IoU-AP / DCC).
"""

import os
import csv
import pickle
from typing import List, Optional

import numpy as np
import torch
import pytorch_lightning as pl
from torch.utils.data import Dataset, DataLoader
from torch_geometric.data import Data, Batch
from sklearn.model_selection import train_test_split


def _load_split_ids(path: str) -> set:
    with open(path) as f:
        r = csv.reader(f)
        next(r, None)                                 # header 'uniprot'
        return set(row[0] for row in r if row)


class UniSiteSetPredDataset(Dataset):
    def __init__(self, records: List[dict]):
        self.records = records

    def __len__(self):
        return len(self.records)

    def __getitem__(self, i):
        r = self.records[i]
        d = Data()
        d.protein_id = r["name"]
        d.pos = torch.from_numpy(np.asarray(r["coordinates"], dtype=np.float32))
        d.esm = torch.from_numpy(np.asarray(r["res_features_esm"], dtype=np.float32))
        d.z = torch.from_numpy(np.asarray(r["z"], dtype=np.int64))
        d.num_nodes = int(r["num_residues"])
        # per-node training targets
        d.y = torch.from_numpy(np.asarray(r["res_binding"], dtype=np.int64))            # foreground
        d.q_centerness = torch.from_numpy(np.asarray(r["q_centerness"], dtype=np.int64))
        d.vote_target = torch.from_numpy(np.asarray(r["vote_target"], dtype=np.float32))  # [N,3]
        # per-graph SET target (kept out of PyG collation; used only at eval)
        target = {
            "site_masks": np.asarray(r["site_masks"], dtype=np.float32),        # [K, N]
            "site_centroids": np.asarray(r["site_centroids"], dtype=np.float32),  # [K, 3]
            "center_res_idx": np.asarray(r["center_res_idx"], dtype=np.int64),   # [K] local node idx per site
        }
        return d, target


def collate_setpred(batch):
    datas = [b[0] for b in batch]
    targets = [b[1] for b in batch]
    g = Batch.from_data_list(datas)
    g.targets = targets                                # List[dict], length = num_graphs
    return g


class UniSiteSetPredDataModule(pl.LightningDataModule):
    def __init__(self,
                 processed_pkl: str,
                 split_dir: str,
                 split: str = "0.9",
                 batch_size: int = 8,
                 num_workers: int = 0,
                 val_frac: float = 0.05,
                 random_seed: int = 42,
                 pin_memory: bool = True,
                 limit: int = 0,
                 **kwargs):
        super().__init__()
        self.save_hyperparameters()
        self._prepared = False

    def prepare_data(self):
        pass

    def setup(self, stage: Optional[str] = None):
        if self._prepared:
            return
        with open(self.hparams.processed_pkl, "rb") as f:
            recs = pickle.load(f)
        if self.hparams.limit:
            recs = recs[: self.hparams.limit]
        by_name = {r["name"]: r for r in recs}
        all_names = list(by_name.keys())

        sp = str(self.hparams.split)
        sd = self.hparams.split_dir
        if sp in ("0.5", "0.7", "0.9"):
            train_ids = _load_split_ids(os.path.join(sd, f"_train_{sp}.csv"))
            test_ids = _load_split_ids(os.path.join(sd, f"_test_{sp}.csv"))
        elif sp == "benchmark":
            train_ids = _load_split_ids(os.path.join(sd, "_train_benchmark.csv"))
            test_ids = _load_split_ids(os.path.join(sd, "_test_benchmark.csv"))
        else:  # "random": ignore CSVs, split the loaded records (dev use)
            tr, te = train_test_split(all_names, train_size=0.9, random_state=self.hparams.random_seed)
            train_ids, test_ids = set(tr), set(te)

        train_names = [n for n in all_names if n in train_ids]
        test_names = [n for n in all_names if n in test_ids]
        # carve val from train
        if len(train_names) > 1 and self.hparams.val_frac > 0:
            tr_names, val_names = train_test_split(
                train_names, test_size=self.hparams.val_frac, random_state=self.hparams.random_seed)
        else:
            tr_names, val_names = train_names, test_names[: max(1, len(test_names) // 10)]

        self.train_set = UniSiteSetPredDataset([by_name[n] for n in tr_names])
        self.val_set = UniSiteSetPredDataset([by_name[n] for n in val_names])
        self.test_set = UniSiteSetPredDataset([by_name[n] for n in test_names])
        self._prepared = True
        print(f"[setpred-dm] split={sp} | train={len(self.train_set)} "
              f"val={len(self.val_set)} test={len(self.test_set)} "
              f"(loaded {len(recs)} records)")

    def _dl(self, ds, shuffle):
        return DataLoader(ds, batch_size=self.hparams.batch_size, shuffle=shuffle,
                          num_workers=self.hparams.num_workers, pin_memory=self.hparams.pin_memory,
                          collate_fn=collate_setpred,
                          persistent_workers=self.hparams.num_workers > 0)

    def train_dataloader(self):
        return self._dl(self.train_set, True)

    def val_dataloader(self):
        return self._dl(self.val_set, False)

    def test_dataloader(self):
        return [self._dl(self.test_set, False)]

    def get_test_loader_names(self):
        return [f"unisite_test_{self.hparams.split}"]

    def print_dataset_summary(self):
        if not self._prepared:
            self.setup()
        print(f"[setpred-dm] ready (split={self.hparams.split}, batch_size={self.hparams.batch_size})")


def create_setpred_datamodule(**kwargs) -> UniSiteSetPredDataModule:
    return UniSiteSetPredDataModule(**kwargs)
